// Yunning Chen
// 5272778

// Declare your FOUR functions here (no more, no less):
// That is, the 3 functions for the selectionSort:
// swap_values, find_index_of_swap, sort
// plus the function getArray
void sort(bool order, int a[], int asize, int start);
// Pre-condition: Function takes in a Boolean variable that holds the sorting direction choice,
//                an integer array, the size of the array, and the starting index.
// Post-condition: This recursive function then sort the array with required order direction

int find_index_of_swap(bool direction, int ar[], int size, int start_index);
// Pre-condition: Function takes in a Boolean variable that holds the sorting direction choice,
//                an integer array, the size of the array, and the starting index.
// Post-condition: This function will return the index used for swaping.

void swap_values(int& v1, int& v2);
// Pre-condition: This function takes in two integers v1 and v2.
// Post-condition: The function will swap v1 and v2.

void getArray(ifstream& in, string fname, int arr[], int size);
// Pre-condition:(same as lab4) This function reads a text file that contains only integers.
// Post-condition: The function places the integers in an array. 

// Constants for the data file that your program is reading in
// Only change these if you want to test your program with a different array file
// than the one provided for you (ArrayFile.txt).
//
const int MAXSIZE = 20;     // amount of integers in the file (you need this to declare your array size)
const std::string FILENAME = "ArrayFile.txt";    // The file name with the integers

