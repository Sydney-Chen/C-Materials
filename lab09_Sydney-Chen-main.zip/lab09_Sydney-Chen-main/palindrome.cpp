// Yunning Chen
// 5272778

#include <iostream>
#include <fstream>
#include <cctype>
#include <string>
using namespace std;

void cleanUp(string &str);
// Pre-condition: This function will take in a string.
// Post-condition: The function will keep only alphabet characters of 
//                 the string and convert them all to lower case.

bool isPalindrome(string s);
// Pre-condition: This function will take in a string.
// Post-condition: The recursive function will check if the string is a palindrome.
//                 It'll return true if it is, and false otherwise.

int main() {
    string p;
    cout << "Enter sentence:\n";
    getline(cin, p);
    
    cleanUp(p);
    bool answer = isPalindrome(p);
   
    if (answer) {
        cout << "It is a palindrome.\n";
    } else {
        cout << "It is not a palindrome.\n";
    }

    return 0;
}

void cleanUp(string& str){
	string new_str = str;
	str = "";
	// keep only letter in str and change all letters to lower case
	for(int i=0;i<new_str.length();i++){
		if(isalpha(new_str[i])){  // keep only letters
			new_str[i] = tolower(new_str[i]); // change to lower case
			str += new_str[i];
		}
	}
}

bool isPalindrome(string s){
	bool is_palin = false;
	int start(0), end(s.size());  // start is the index of the first letter, and end is the index of the last letter
	
	// Base case: empty string or string with only one letter
	if((s == "") || (s.size() == 1)){
		is_palin = true;
	}
	// Recursive case
	else{
		if(s[0] == s[s.size()-1]){    // check if the letters in first position and last position are the same
			is_palin = isPalindrome(s.substr(start+1,end-2));  // minus 2 because we take off the first AND last letter
		}
	}
	
	return is_palin;
}

