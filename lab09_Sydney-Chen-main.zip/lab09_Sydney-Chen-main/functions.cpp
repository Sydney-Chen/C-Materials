// Yunning Chen
// 5272778

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
using namespace std;

// This function definition is copied from lecture 11
void swap_values(int& v1, int& v2){
	int temp;
	temp = v1;
	v1 = v2;
	v2 = temp;
}

// Recursive function (goal: sort array)
void sort(bool order, int a[], int asize, int start){
	int swap_index;
	
	// Base Case: only one element left in the array
	if(start+1 == asize){
		return;
	}
	// Recursive Case: more than one element in the array
	else{
		swap_index = find_index_of_swap(order,a,asize,start);
		swap_values(a[start], a[swap_index]);
		sort(order, a, asize, start+1);
	}
}

// Non-recursive function (goal: find the index used for swaping)
int find_index_of_swap(bool direction, int ar[], int size, int start_index){
	int index_of_swap = start_index;
	int target = ar[start_index];
	for(int index = start_index + 1; index < size; index++){
		if (((ar[index] > target)&&direction) || ((ar[index] < target)&&!direction)){
			target = ar[index];
			index_of_swap = index;
		}
	}
	
	return index_of_swap;
}

// Next, define the function getArray here. 
// This function definition is copied from lab4
void getArray(ifstream& in, string fname, int arr[], int size)
{
    in.open(fname);
    if ( in.fail() ) 
    { 
        cerr << "Input file opening failed.\n"; 
        exit(1); 
    }
    for (int i = 0; i < size; i++)
    {
        in >> arr[i];
    }
}