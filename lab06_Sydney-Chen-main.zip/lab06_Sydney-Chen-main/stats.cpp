// stats.cpp
// Yunning Chen
// 5272778

#include <iostream>
#include <string>
#include <fstream>
#include <cmath>
using namespace std;

double GetMean(double total, int num_data);
//Pre-condition: Pass the sum of numbers, and how many numbers are there into the function
//Post-condition: The function calculate the mean, then return the mean.

double GetMedian(double my_arr[], int size);
//Pre-condition: Pass an array contains the numbers in the file, and the number of numbers there.
//Post-condition: The function calculate the median, then return the median.

double GetStd(double my_arr[], int size, double sum_array);
//Pre-condition: Pass an array contains the numbers in the file, and the number of numbers there, and the sum of numbers.
//Post-condition: The function calculate the standard deviation, then return the standard deviation.

int main(){
	ifstream in_stream;
	string file_name;
	double file_mean, file_median, file_std, sum(0), in_num;
	int count(0); 
	double arr[1000];  // use an array to store the data in the file
	cout << "Enter filename: ";
	cin >> file_name;
	in_stream.open(file_name);
	// get the sum and the amount of numbers in the file (for later use)
	// store every number into the array (easier to sort and calculate)
	while(in_stream >> arr[count]){
		sum += arr[count];
		count++;
	}
	in_stream.close();  //close connection
	
	file_mean = GetMean(sum, count);
	file_median = GetMedian(arr,count);
	file_std = GetStd(arr,count,sum);
	
	// Formatting output
	cout.setf(ios::fixed);
	cout.setf(ios::showpoint);
	cout.precision(3);

	cout << "Mean = " << file_mean << endl;
	cout << "Median = " << file_median << endl;
	cout << "Stddev = " << file_std << endl;
	
	return 0;
}

// mean function definition
double GetMean(double total, int num_data){
	double average;
	average = total / num_data;
	return average;
}

// median function definition
double GetMedian(double my_arr[], int size){
	int middle;
	double median_num, temp;
	// sorting the numbers in ascending order(bubble sort)
	for (int i = size-1; i >= 0; i--) {
		for (int j = 1; j <= i; j++) {
			if (my_arr[j-1] > my_arr[j]) {
				temp = my_arr[j-1];
				my_arr[j-1] = my_arr[j];
				my_arr[j] = temp;
			} // if
		} // for j
	} // for i
	
	if(size%2==0){                //If there are an even number of numbers
		middle = size/2;
		median_num = (my_arr[middle-1]+my_arr[middle])/2.0;
	}else{                        //odd number of numbers
		middle = (size+1)/2;
		median_num = my_arr[middle-1];
	}
	return median_num;
}

// std function definition
double GetStd(double my_arr[], int size, double sum_array){
	double stddev, avg, var, num;   //num is each number, var is variance, avg is mean and stddev is standard deviation
	double numer(0), denom;         // numerator and denomenator
	// get mean
	avg = GetMean(sum_array,size);
	denom = size-1;
	for(int i=0; i<size; i++){
		num = my_arr[i];
		numer += pow(num-avg,2);
	}
	var = numer/denom;
	stddev = sqrt(var);       // formula in stats: std = sqrt(var)
	return stddev;
}