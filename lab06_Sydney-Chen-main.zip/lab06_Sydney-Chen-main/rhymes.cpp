// rhymes.cpp
// Yunning Chen
// 5272778

#include <iostream>
#include <string>
#include <fstream>
#include <cctype>
using namespace std;

string LastWords(string str);
//Pre-condition: pass a string str into the function
//Post-condition: the function extract the last word of the string

bool CompareWordsEnd(string check_wrd1, string check_wrd2);
//Pre-condition: pass two words into the function
//Post-condition: compare the last two letters of these two words

string CleanWords(string lines);
//Pre-condition: we pass a whole line of string into the function
//Post-condition: we clean out all non-alphabetic and non-space chars

int main(){
	ifstream inf;
	string file_name, line1, line2, word1, word2;
	string test1,test2;   // cleaned version of line1 and line2, use for check rhymes
	bool rhyme(false);
	int num_line(0),count(0);
	double density;
	
	cout << "Enter filename: \n";
	cin >> file_name;
	inf.open(file_name); 
	// check if file exist
	if( inf.fail() ){
		cerr << "Input file opening failed.\n"; 
		exit(1); // Program quits right here!
	}
	
	getline(inf,line1);
	getline(inf,line2);
	num_line = 2;
	
	//run through every line
	while(!inf.eof()){
		if((line2 == "")){
			getline(inf,line1);
			getline(inf,line2);
			num_line += 2;
		}
		test1 = CleanWords(line1);
		test2 = CleanWords(line2);
		rhyme = CompareWordsEnd(test1,test2);
		
		if(rhyme == true){ 		//if they're rhyme, we extract the last word
			word1 = LastWords(test1);
			cout << word1;
			word2 = LastWords(test2);
			cout << " and " << word2 << endl;
			count += 1;
		}
		num_line += 1;
		line1 = line2;
		getline(inf,line2);
	}
	
	inf.close();   //close file
	num_line -= 1;  // Get rid of the count of the last empty line
	// formatting output
	cout.setf(ios::fixed);
	cout.setf(ios::showpoint);
	cout.precision(2);
	
	if(count>1){  //There's rhyme
		density = static_cast<double>(count)/num_line;
		cout << "There are " << count << " pairs of rhyming words.\n";
		cout << "There are " << num_line << " lines in this poem, so the rhyme-line density is: " << density << endl;
	}
	else if(count == 1){
		density = static_cast<double>(count)/num_line;
		cout << "There is " << count << " pair of rhyming words.\n";
		cout << "There are " << num_line << " lines in this poem, so the rhyme-line density is: " << density << endl;
	}
	else{    // no rhyme
		cout<<"No rhymes found.\n";
		cout<< "There are " << num_line << " lines in this poem.\n";
	}
	
	
	return 0;
}

string CleanWords(string lines){
	int k = 0;
	while(k<lines.length()){
		// get rid of non-alphabetic chars.
		if(lines[k] != ' '){
			if(!(isalpha(lines[k]))){  
				lines.erase(k,1);
				k -= 1;
			}
		}
		k++;
	}
	
	// delete everything not alphabetical at the end (like whitespace)
	if(!(isalpha(lines[lines.length()-1]))){
		lines.erase(lines.length()-1,1);
	}
	
	return lines;
}

string LastWords(string str){
	string last_word;
	int last_pos = str.length()-1;
	int len_of_word;
	// find the last white space since it's right before the last word
	while((!(str[last_pos] == ' ')) && (last_pos>=0)){
		last_pos = last_pos-1;
	}
	last_pos = last_pos+1;
	len_of_word = str.length() - last_pos;
	last_word = str.substr(last_pos,len_of_word);
	return last_word;
}

bool CompareWordsEnd(string check_str1, string check_str2){
	bool same(false);
	char last1, second_last1;   //last letter and second-last letter of check str1
	char last2, second_last2;   //last letter and second-last letter of check str2
	
	last1 = check_str1[check_str1.length()-1];
	second_last1= check_str1[check_str1.length()-2];
	last2 = check_str2[check_str2.length()-1];
	second_last2 = check_str2[check_str2.length()-2];
	if((last1 == last2) && (second_last1 == second_last2)){
		same = true;
	}
	
	return same;
}