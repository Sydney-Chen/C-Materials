// block.cpp
// Yunning Chen
// 5272778

#include <iostream>
using namespace std;

int main()
{
	int row, col,count1,count2;
	cout << "Enter number of rows and columns:\n";
	cin >> row;
	cin >> col;
	
	// quit when column and row are 0
	// check if column or row is 0
	while(row != 0 || col != 0){
		// draw 'X.' for each line(row)
		for(count1=1;count1<=row;count1++){
			// draw 'X.' for each column in each row.
			for(count2=1;count2<=col;count2++){
				cout << "X.";
			}
			cout << endl;
		}
		cout << "Enter number of rows and columns:\n";
		cin >> row;
		cin >> col;
	}
	
	
    return 0;
}