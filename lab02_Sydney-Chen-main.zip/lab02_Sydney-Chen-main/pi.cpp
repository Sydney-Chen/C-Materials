// pi.cpp
// Yunning Chen
// 5272778

#include <iostream>
#include <cmath>
using namespace std;

int main()
{
	int terms(1);
	// we need pi, and we might need a new_count as a copy of count below to edit.
	double pivalue(0), new_count(0);
	// we need a count in the loop
	int count(1);
	
	// You need to do something about the formatting requirement here!
	cout.setf(ios::fixed);
	cout.setf(ios::showpoint);
	cout.precision(5);
	
	// You also need to do a loop here that keeps asking for number of terms and then calculates pi!
	cout << "Enter the number of terms to approximate (or zero to quit):\n";
	cin >> terms;
	// run when the term is not 0
	while(terms != 0){
		pivalue = 1;
		// check from 1 to the number of terms, 1 by 1.
		for(count=1;count<=terms;count++){
			// set condition: odd term should be negative.
			if(count%2 != 0){
				new_count = count*(-1);
				new_count = new_count + new_count - 1;
				new_count = 1/new_count;
			}else{
				new_count = count + count + 1;
				new_count = 1/new_count;
			}
			// add up each element
			pivalue += new_count;
		}
		// times 4 (last part of the formula)
		pivalue = pivalue*4;
		// another round.
		cout << "The approximation for Leibniz's Formula is " << pivalue << " using " << terms << " terms.\n";
		cout << "Enter the number of terms to approximate (or zero to quit):\n";
		cin >> terms;
	}
	
	// HINT: You can use cmath for its pow() function, which calculates x raised to the power y when used like: pow(x,y)
	
	
	return 0;
}