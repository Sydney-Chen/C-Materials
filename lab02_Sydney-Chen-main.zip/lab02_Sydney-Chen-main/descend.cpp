// DESCEND.CPP
// Yunning Chen
// 5272778

#include <iostream>
using namespace std;

int main()
{
	// name input numbers num#
	int num1, num2, num3;
	cin >> num1;
	cin >> num2;
	cin >> num3;
	
	// Check from num1 being the biggest number
	if(num1>=num2 && num1>=num3){
		if(num2>=num3){
			cout << num1 << " " << num2 << " "<< num3 <<endl;
		}else{
			cout << num1 << " " << num3 << " "<< num2 <<endl;
		}
	}else if(num2>=num1 && num2>=num3){                          // check from num2 being the biggest number//
		if(num1>=num3){
			cout << num2 << " " << num1 << " "<< num3 <<endl;
		}else{
			cout << num2 << " " << num3 << " "<< num1 <<endl;
		}
	}else if(num3>=num2 && num3>=num3){                         // check from num3 being the biggest number//
		if(num1>=num2){
			cout << num3 << " " << num1 << " "<< num2 <<endl;
		}else{
			cout << num3 << " " << num2 << " "<< num1 <<endl;
		}
	}
	
	
		
	
    return 0;
}
