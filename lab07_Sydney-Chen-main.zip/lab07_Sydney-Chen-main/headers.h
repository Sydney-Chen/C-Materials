// Yunning Chen

/*#include <iostream>
#include <string>
#include <fstream>*/

using namespace std;
// DEFINE STRUCTURE HERE -- MISSING!
struct UndergradStudents {
	int id;
	string first_name;
	string last_name;
	string major;
	double gpa1;
	double gpa2;
	double gpa3;
	double gpa4;
};
void InitializeStructures(UndergradStudents us[], int &size);
void WriteResults(ofstream &outf, UndergradStudents us[], int size);
// DECLARE FUNCTIONS HERE.
// I've already declared 2 functions for you (in records.cpp)
//
// You may add other function declarations in here as well, if you want to.
// See hint in the lab description document.
void SortLastName(UndergradStudents arr[], int size_ar);
//Pre-condition: takes in a structure array of students information and its size, 
//Post-condition: Sort the array in ascending alphabetical order of the last name.