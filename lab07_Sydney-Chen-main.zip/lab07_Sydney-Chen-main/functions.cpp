// Yunning Chen

// DEFINE YOUR FUNCTIONS HERE
// They have to be declared in the "headers.h" file.
//
// You *have* to use these 2 functions (already declared in records.cpp), 
// but you may add other functions in here as well, if you want.
// See hint in the lab description document.

#include <iostream>
#include <string>
#include <fstream>

using namespace std;

void InitializeStructures(UndergradStudents us[], int &size) {
	//  initialize all the values of us[]
	UndergradStudents stu; // stu means student
	string temp1;
	size = 1;
	cout << "Enter first name for student " << size << " (or X to quit): ";
	getline(cin,stu.first_name);
	
	while(size<=20 && (stu.first_name != "X")){
		stu.id = size;
		
		cout << "Enter last name for student "<<size<<": ";
		getline(cin,stu.last_name);
		cout << "Enter major for student "<<size<<": ";
		cin >> stu.major;
		cout << "Enter GPA Year 1 for student "<<size<<": ";
		cin >> stu.gpa1;
		cout << "Enter GPA Year 2 for student "<<size<<": ";
		cin >> stu.gpa2;
		cout << "Enter GPA Year 3 for student "<<size<<": ";
		cin >> stu.gpa3;
		cout << "Enter GPA Year 4 for student "<<size<<": ";
		cin >> stu.gpa4;
		getline(cin,temp1);  // read the last space character
		
		// initialize us[]
		us[size-1] = stu;
		cout<<endl;
		
		// another round
		size++;
		if(size<=20){
			cout << "Enter first name for student " << size << " (or X to quit): ";
			getline(cin,stu.first_name);
		}
	}
	size -= 1;  // it added one more before it get out of the loop
}

void WriteResults(ofstream &outf, UndergradStudents us[], int size){
	double average_gpa;
	SortLastName(us,size);   // Sort last name
	
	outf.open("Results.txt");   //open connection
	outf << "These are the sorted results:\n";
	
	outf.setf(ios::fixed);
	outf.setf(ios::showpoint);
	outf.precision(2);
	
	for(int i=0;i<size;i++){  
		average_gpa = static_cast<double>((us[i].gpa1) + (us[i].gpa2) + (us[i].gpa3) + (us[i].gpa4))/4.0;
		outf << "ID# " << us[i].id << ", " << us[i].last_name;
		outf << ", " << us[i].first_name << ", " << us[i].major;
		outf << ", Average GPA: " << average_gpa << endl;
	}
	outf.close();  //close connection
}


void SortLastName(UndergradStudents arr[], int size_ar){
	UndergradStudents temp;
	// bubble sort
	for(int i = size_ar-1; i >= 0; i--){
		for (int j = 1; j <= i; j++) {
			// we only sort when alphabetic order is descending
			if (arr[j-1].last_name > arr[j].last_name) {
				temp = arr[j-1];
				arr[j-1] = arr[j];
				arr[j] = temp;
			}
			
		}
	}
}
