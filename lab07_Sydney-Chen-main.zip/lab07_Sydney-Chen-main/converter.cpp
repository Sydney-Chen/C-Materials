// converter.cpp
// Yunning Chen
// 5272778

#include <iostream>
#include <string>
#include <cctype>

using namespace std;

string convertFromDec(unsigned int decnum, unsigned int base);
// Pre-condition: The function will takes in 2 arguments: an unsigned int 
// representing a decimal number, and an unsigned int representing a
// converting base.
// Post-condition: The function will then convert the decimal to the base passed in.

int main(){
	string dec_num, bi_num, oct_num, hex_num;
	int num;
	cout << "Enter positive decimal number (anything else quits): ";
	cin >> dec_num;
	for(int i=0;i<dec_num.length();i++){
		// only run when it's a positive number
		while((isdigit(dec_num[i])) && (stoi(dec_num)>0)){
			num = stoi(dec_num);    //convert to integer
			// convert to binary
			bi_num = convertFromDec(num,2);       
			cout<< num << " in binary is: ";
			for(int i=0;i<=bi_num.length()-1;i++){ //print it backward
				cout<<bi_num[bi_num.length()-1-i];
			}
			cout<<endl;
			
			// convert to octal
			oct_num = convertFromDec(num,8);      
			cout<< num << " in octal is: ";
			for(int i=0;i<=oct_num.length()-1;i++){  //print it backward
				cout<<oct_num[oct_num.length()-1-i];
			}
			cout<<endl;
			
			// convert to hexadecimal
			hex_num = convertFromDec(num,16);     
			cout<< num << " in hex is: ";
			for(int i=0;i<=hex_num.length()-1;i++){  //print it backward
				cout<<hex_num[hex_num.length()-1-i];
			}
			cout<<endl;
			
			// Another round
			cout<<endl;
			cout << "Enter positive decimal number (anything else quits): ";
			cin >> dec_num;
		}
	}
	
	return 0;
}

string convertFromDec(unsigned int decnum, unsigned int base){
	string final_num="";
	char element; //each element in the final_num
	int remainder;
	while(decnum>0){
		remainder = decnum%base;
		//In base 16, numbers >10 is a letter
		if((base==16) && (remainder>=10)){
			remainder += 55;
			element = remainder;
			final_num += element;
		}
		else{
			final_num += to_string(remainder);
		}
		decnum = decnum/base;
	}
	
	return final_num;
}