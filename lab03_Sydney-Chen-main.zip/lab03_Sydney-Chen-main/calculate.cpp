// calculate.cpp (lab03)
// Yunning Chen
// 5272778
// Created on: 10/20/2020

#include <iostream>
#include <cstdlib>
using namespace std;
// Usage: ./calculate int char int
// char can be one of 3 things: + x or %
int main( int argc, char *argv[] ){
    // PART 1: Check to see if the number of arguments is correct
    // Hint: use “if (argc ...)” to check this,
    // use cerr to output any messages
    if(argc == 4){   //check if the number of arguments is correct
        int num1, num2, output; //output is the result being print out.
        char operation = argv[2][0];
        
        // PART 2: Convert arguments into integers (only those that need it!)
        // Hint: this means using atoi()
        num1 = atoi(argv[1]);
        num2 = atoi(argv[3]);
        // PART 3: Check for illegal operations like divide by zero...
        // use cerr to output any messages
        if((operation == '%') && (num2 == 0)){   //check if numerator is 0 in %
            cerr << "Cannot divide by zero.\n";
			exit(1);
        }
        // PART 4: Do the appropriate calculations,
        // outputs using both cout and cerr, etc...
        else{
            if(operation == '+'){
                cout << num1 + num2 << endl;
            }
            else if(operation == 'x'){
                cout << num1 * num2 << endl;
            }
            else if(operation == '%'){
                cout << num1 % num2 << endl;
            }
            else{ // make sure no other operations allowed
                cerr << "Bad operation choice.\n";
				exit(1);
            }
        }
    }
    else{    // error message when the number of argument is incorrect
        cerr << "Number of arguments is incorrect.\n";
		exit(1);
    }
 return 0;
}