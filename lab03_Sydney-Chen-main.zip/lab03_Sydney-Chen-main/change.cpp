// change.cpp (lab03)
// Yunning Chen
// 5272778

#include <iostream>
using namespace std;

void compute_coins(int amount);
//Pre-condition: The function takes in 1 arguments: an int amount.
//Post-Condition: The function will print out the change of the cent into quarter, dime and penny.

void compute_coins(int amount){
    if((amount>0) && (amount<=99)){
		if(amount == 1){
			cout << "1 cent can be given in 1 penny.\n";   // only one penny.
		}
		else{
			cout << amount << " cents can be given in ";
			// check for quarter(s)
			if(amount>=25){      // if the amount is larger than 25
				if(amount%25 == 0){        // if the amount can be divided evenly.
					if(amount/25 == 1){    // only 1 quarter
						cout << "1 quarter.\n";
					}
					else{         // more than 1 quarters(plural)
						cout << amount/25 << " quarters.\n";
					}
				}
				else{    //if the amount can't be changed only by quarters
					if(amount/25 == 1){    // only 1 quarter
						cout << "1 quarter, ";
					}
					else{         // more than 1 quarters(plural)
						cout << amount/25 << " quarters, ";
					}
				}
				amount = amount%25; // will be 0 if it can be divided evenly, and not 0 if not
			}
        
			// check for dime(s)
			if(amount>=10){      // if the amount is larger than 10
				if(amount%10 == 0){        // if the amount can be divided evenly.
					if(amount/10 == 1){    // only 1 dime
						cout << "1 dime.\n";
					}
					else{         // more than 1 dimes(plural)
						cout << amount/10 << " dimes.\n";
					}
				}
				else{    //if the amount can't be changed only by dimes
					if(amount/10 == 1){    // only 1 dime
						cout << "1 dime, ";
					}
					else{         // more than 1 dimes(plural)
						cout << amount/10 << " dimes, ";
					}
				}
				amount = amount%10; // will be 0 if it can be divided evenly, and not 0 if not
			}   
            
			// check for penny(ies)
			if(amount>0){ 			// (still have remaining)
				if(amount == 1){
					cout << "1 penny.\n";
				}
				else{
			    cout<< amount << " pennies.\n";   // only plural since we checked 1 penny 
			   }
			}
        }
    }
    else{
        cout << "Amount is out of bounds. Must be between 1 and 99.\n";
    }
}



int main(){
    int input_num;
    cout<<"Enter number of cents (or zero to quit):\n";
    cin >> input_num;
    // change the cent until 0 appear
    while(input_num != 0){
        compute_coins(input_num);
        // ask for inputs again
        cout<<"Enter number of cents (or zero to quit):\n";
        cin >> input_num;
    }

    return 0;
}