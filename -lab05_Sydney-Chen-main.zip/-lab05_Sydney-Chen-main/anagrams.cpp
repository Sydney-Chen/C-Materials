// anagrams.cpp
// Yunning Chen (Sydney)
// 5272778

#include <iostream>
#include <string>
#include <cctype>
using namespace std;

bool is_anagrams(string sentence1, string sentence2);
//Pre-Condition: We pass two strings (sentences) into the funtion and determine if they're the same
//Post-Condition: return true if they're the same, return false if they are not.

int main()
{
    // declare those two original strings as str1, str2. 
	// And two cleaned strings to compare are new_str1, new_str2
	string str1, str2;
	string new_str1="", new_str2="";
	// and boolean to check if they're anagrams
	bool check_str;
	
	// Get strings from user
	cout << "Enter first string:\n";
	getline(cin,str1);
	cout << "Enter second string:\n";
	getline(cin,str2);
	
	// Clean strings
	// step1: keep only letter in str1 and change all letters in str1 to lower case
	for(int i=0;i<str1.length();i++){
		if(isalpha(str1[i])){  // keep only letters
			str1[i] = tolower(str1[i]);  // change to lower case
			new_str1 += str1[i];
		}
	}
	
	// step2: keep only letters in str2 and change all letters in str2 to lower case
	for(int i=0;i<str2.length();i++){
		if(isalpha(str2[i])){  // keep only letters
			str2[i] = tolower(str2[i]); // change to lower case
			new_str2 += str2[i];
		}
	}
	
	//Step 3: sorting new_str1 and new_str2 (bubble sort)
	// The codes are changed by the code on textbook, ch7, p459 (global edition)
	for(int i=new_str1.length()-1; i>0; i--){
		for(int j=0; j<i; j++){
			if(new_str1[j]>new_str1[j+1]){
				char temp = new_str1[j+1];
				new_str1[j+1] = new_str1[j];
				new_str1[j] = temp;
			}
		}
	}
	
	for(int i=new_str2.length()-1; i>0; i--){   // same as the last for loop, just change to new_str2
		for(int j=0; j<i; j++){
			if(new_str2[j]>new_str2[j+1]){
				char temp = new_str2[j+1];
				new_str2[j+1] = new_str2[j];
				new_str2[j] = temp;
			}
		}
	}
	
	// Check to see if they are anagrams
	check_str = is_anagrams(new_str1, new_str2);
	// Report if they are or not anagrams
	if(check_str == true){
		cout << "The strings are anagrams.\n";
	}
	else{
		cout<< "The strings are not anagrams.\n";
	}
	
    return 0;
}

bool is_anagrams(string sentence1, string sentence2){
	bool indicate;
	if(sentence1 == sentence2){    // sentence 1 and 2 are the same, they're anagrams
		indicate = true;
	}
	else{
		indicate = false;
	}
	return indicate;
}
