// sentence.cpp
// Yunning Chen
// 5272778

#include <iostream>
#include <string>
#include <cctype>
using namespace std;

void sort_string(string& user_sentence, int size);
//pre-condition: pass a string user_sentence and an integer size (of that string)into the function, clean the string and sort it
//post-condition: the string is cleaned and sorted, then print out the sorted, clean string.

void print_freq(string sentence2, int size2);
//pre-condition: pass the cleaned, sotred string into the function, check the number of times every character appears
//post-condition: print out every character and its corresponding frequency

int main()
{
    string sentence;
    cout << "Enter sentence: ";
	getline(cin,sentence);
	
    sort_string(sentence, sentence.size());
    print_freq(sentence, sentence.size());

	return 0;
}

void sort_string(string& user_sentence, int size){
	// Let's clean the sentence first
	// Check alphabetic
	string new_sentence= "";  
	for(int i=0; i<user_sentence.length(); i++){
		// keep only letters in the new string
		if(isalpha(user_sentence[i])){
			new_sentence += user_sentence[i];
		}
	}
	
	// Then Sort It (bubble-sort)
	// The code is changed by the code on textbook, ch7, p459 (global edition)
	for(int i=new_sentence.length()-1; i>0; i--){
		for(int j=0; j<i; j++){
			if(new_sentence[j]>new_sentence[j+1]){
				char temp = new_sentence[j+1];
				new_sentence[j+1] = new_sentence[j];
				new_sentence[j] = temp;
			}
		}
	}
	
	//replace the old sentence
	user_sentence = new_sentence;
	cout << "Sorted and cleaned-up sentence:" << user_sentence << endl;
}

void print_freq(string sentence2, int size2){
	for(int i=0; i<sentence2.length();i++){      // run through every char on their first occurance
		int count = 1;
		for(int j=i+1; j<sentence2.length();j++){   // compare every char after that char to see if they're the same
			if(sentence2[i] == sentence2[j]){
				count += 1;
			}
		}
		
		if(count != 1){     // delete repeat chars (only keep the first appeared one)
			sentence2.erase(i+1, count-1);
		}
		
		cout << sentence2[i] << ": " << count << endl;
	}	
	
}