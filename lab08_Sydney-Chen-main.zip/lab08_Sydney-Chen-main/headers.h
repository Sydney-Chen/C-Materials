class AString {
	public:
		// constructors
		AString();
		// will not take arguments and set the value of the member variable to an empty string
		
		AString(string user_str);
		// will take one argument to initialize the memember variable.
	
		// Member functions
		void getAString();     
		//Pre-condition: The function ask the user for an input.
		//Post-condition: The input is assigned to the member variable StringValue.
		
		void cleanUp();        
		//Pre-condition: The function takes no argument.
		//Post-condition: Removing all non-alphabet characters in it and then 
		//                transforming all the remaining to lower-case characters.
		
		void countLetters(int arr[]);   // mutator function
		//Pre-condition: The function takes an integer array of size 26
		//Post-condition: Count the frequency of occurrence of all the letters in  
        //                StringValue and place that count in the integer array
		
	private:
		// member variable called StringValue
		string StringValue;
};

// Declare the program function used in the main routine called compareCounts here:
// type compareCounts(arguments);

bool compareCounts(int arr1[], int arr2[]);
//Pre-condition: The function takes in 2 integer arrays each of size 26
//Post-condition: The function should compare to see that the 2 arrays are the same.
//                It returns a Boolean value of true if it is and false otherwise.