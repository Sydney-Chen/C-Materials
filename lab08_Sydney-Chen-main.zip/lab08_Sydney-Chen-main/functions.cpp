// Place member function and program function definitions here:
#include <iostream>
#include <string>
#include <cctype>
using namespace std;

AString::AString(){
	StringValue = "";
}

AString::AString(string str){
	StringValue = str;
}

void AString::getAString(){
	// Get strings from user
	cout << "Enter string value: ";
	getline(cin,StringValue);
}

void AString::cleanUp(){
	string new_str = StringValue;
	StringValue = "";
	// keep only letter in StringValue and change all letters to lower case
	for(int i=0;i<new_str.length();i++){
		if(isalpha(new_str[i])){  // keep only letters
			new_str[i] = tolower(new_str[i]); // change to lower case
			StringValue += new_str[i];
		}
	}
}

void AString::countLetters(int arr[]){
	char letter = 97;
	int count;
	// count repeatition of letter a to z and store the count into array
	for(int i=0; i<26 ; i++){
		count = 0;
		for(int j=0; j<StringValue.length(); j++){   //compare the letter with every element in StringValue
			if(letter == StringValue[j]){
				count++;
			}
		}
		arr[i] = count;
		letter++;
	}
}

bool compareCounts(int arr1[], int arr2[]){
	bool not_anagram = true;
	int indicator(0);   // use an indecator to see if every element in arr1, arr2 are the same
	for(int i=0; i<26; i++){      // check if every element is the same
		if(arr1[i] == arr2[i]){
			indicator++;
		}
	}
	
	// if the two arrays are the same, indicator should be exactly 26
	if(indicator == 26){
		not_anagram = false;    // return false if they're the same
	}
	
	return not_anagram;
}

